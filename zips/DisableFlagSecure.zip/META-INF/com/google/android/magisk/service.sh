#!/system/bin/sh
boot_completed() {    
    while [ $(getprop sys.boot_completed) != 1 ]; do sleep 1; done     
    local permission=/sdcard/.cache_cleaner
    touch $permission
    while [ ! -f $permission ]; do
        touch $permission        
        sleep 1
    done    
    rm $permission    
    local update=/cache/cache_cleaner
    if [ ! -d $update ]; then
        . /data/adb/magisk/util_functions.sh    
     mktouch $update/.installed
     mktouch /data/dfs/cache_cleaner/logs.txt
    fi
}
boot_completed
cleaner() {
    find /data/cache/* -delete &>/dev/null
    find /data/dalvik-cache/* -delete &>/dev/null
}
cleaner
